package com.thegamingjourney.service;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.thegamingjourney.config.DbConfig;
import com.thegamingjourney.model.*;

public class GamesPageService {
    private static final int DEFAULT_LIMIT = 12;
    
    /**
     * Fetches popular games sorted by a combination of reviews and ratings.
     * @param limit Maximum number of games to fetch (defaults to 12 if <= 0).
     * @return List of GameModel objects, or empty list if error occurs.
     */
    public List<GamesPageModel> getPopularGames(int limit) {
        int queryLimit = (limit > 0) ? limit : DEFAULT_LIMIT;
        String sql = "SELECT * from Games";
        try (Connection conn = DbConfig.getDbConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, queryLimit);
            return executeGameQuery(stmt);
        } catch (SQLException | ClassNotFoundException e) {
            System.err.println("[ERROR] getPopularGames failed: " + e.getMessage());
            return new ArrayList<>(); // Fail gracefully
        }
    }
    
    /**
     * Fetches top rated games sorted by rating.
     * @param limit Maximum number of games to fetch (defaults to 12 if <= 0).
     * @return List of GameModel objects, or empty list if error occurs.
     */
    public List<GamesPageModel> getTopRatedGames(int limit) {
        int queryLimit = (limit > 0) ? limit : DEFAULT_LIMIT;
        String sql = "SELECT g.gameId as GameID, g.title as GameName, gr.name as Genre, " +
                     "g.developer as Developer, g.imagesUrl as ImageURL, g.avgRating as Rating, " +
                     "(SELECT COUNT(*) FROM reviews r WHERE r.gameId = g.gameId) as NumberOfReviews " +
                     "FROM games g " +
                     "JOIN genres_games gg ON g.gameId = gg.gameId " +
                     "JOIN genres gr ON gg.genreId = gr.genreId " +
                     "ORDER BY g.avgRating DESC LIMIT ?";
        try (Connection conn = DbConfig.getDbConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, queryLimit);
            return executeGameQuery(stmt);
        } catch (SQLException | ClassNotFoundException e) {
            System.err.println("[ERROR] getTopRatedGames failed: " + e.getMessage());
            return new ArrayList<>(); // Fail gracefully
        }
    }
    
    /**
     * Fetches popular games of a specific genre based on reviews and ratings.
     * @param genre The genre to filter by.
     * @param limit Maximum number of games to fetch (defaults to 12 if <= 0).
     * @return List of GameModel objects, or empty list if error occurs.
     */
    public List<GamesPageModel> getPopularGamesByGenre(String genre, int limit) {
        int queryLimit = (limit > 0) ? limit : DEFAULT_LIMIT;
        String sql = "SELECT g.gameId as GameID, g.title as GameName, gr.name as Genre, " +
                     "g.developer as Developer, g.imagesUrl as ImageURL, g.avgRating as Rating, " +
                     "(SELECT COUNT(*) FROM reviews r WHERE r.gameId = g.gameId) as NumberOfReviews " +
                     "FROM games g " +
                     "JOIN genres_games gg ON g.gameId = gg.gameId " +
                     "JOIN genres gr ON gg.genreId = gr.genreId " +
                     "WHERE gr.name = ? " +
                     "ORDER BY (g.avgRating * (SELECT COUNT(*) FROM reviews r WHERE r.gameId = g.gameId)) DESC LIMIT ?";
        try (Connection conn = DbConfig.getDbConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, genre);
            stmt.setInt(2, queryLimit);
            return executeGameQuery(stmt);
        } catch (SQLException | ClassNotFoundException e) {
            System.err.println("[ERROR] getPopularGamesByGenre failed: " + e.getMessage());
            return new ArrayList<>(); // Fail gracefully
        }
    }
    
    /**
     * Fetches top rated games of a specific genre.
     * @param genre The genre to filter by.
     * @param limit Maximum number of games to fetch (defaults to 12 if <= 0).
     * @return List of GameModel objects, or empty list if error occurs.
     */
    public List<GamesPageModel> getTopRatedGamesByGenre(String genre, int limit) {
        int queryLimit = (limit > 0) ? limit : DEFAULT_LIMIT;
        String sql = "SELECT g.gameId as GameID, g.title as GameName, gr.name as Genre, " +
                     "g.developer as Developer, g.imagesUrl as ImageURL, g.avgRating as Rating, " +
                     "(SELECT COUNT(*) FROM reviews r WHERE r.gameId = g.gameId) as NumberOfReviews " +
                     "FROM games g " +
                     "JOIN genres_games gg ON g.gameId = gg.gameId " +
                     "JOIN genres gr ON gg.genreId = gr.genreId " +
                     "WHERE gr.name = ? " +
                     "ORDER BY g.avgRating DESC LIMIT ?";
        try (Connection conn = DbConfig.getDbConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, genre);
            stmt.setInt(2, queryLimit);
            return executeGameQuery(stmt);
        } catch (SQLException | ClassNotFoundException e) {
            System.err.println("[ERROR] getTopRatedGamesByGenre failed: " + e.getMessage());
            return new ArrayList<>(); // Fail gracefully
        }
    }
    
    /**
     * Fetches a single game by ID (useful for game details page).
     * @param gameID The ID of the game to fetch.
     * @return GameModel if found, null otherwise.
     */
    public GamesPageModel getGameById(int gameID) {
        String sql = "SELECT g.gameId as GameID, g.title as GameName, g.description as Description, " +
                     "gr.name as Genre, g.developer as Developer, g.imagesUrl as ImageURL, " +
                     "g.relaseDate as ReleasedDate, g.avgRating as Rating, " +
                     "(SELECT COUNT(*) FROM reviews r WHERE r.gameId = g.gameId) as NumberOfReviews " +
                     "FROM games g " +
                     "JOIN genres_games gg ON g.gameId = gg.gameId " +
                     "JOIN genres gr ON gg.genreId = gr.genreId " +
                     "WHERE g.gameId = ?";
        try (Connection conn = DbConfig.getDbConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, gameID);
            List<GamesPageModel> result = executeGameQuery(stmt);
            return result.isEmpty() ? null : result.get(0);
        } catch (SQLException | ClassNotFoundException e) {
            System.err.println("[ERROR] getGameById failed: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Fetches all available genres.
     * @return List of genre names, or empty list if error occurs.
     */
    public List<String> getAllGenres() {
        String sql = "SELECT name FROM genres ORDER BY name";
        try (Connection conn = DbConfig.getDbConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            List<String> genres = new ArrayList<>();
            while (rs.next()) {
                genres.add(rs.getString("name"));
            }
            return genres;
        } catch (SQLException | ClassNotFoundException e) {
            System.err.println("[ERROR] getAllGenres failed: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    
    // ===== PRIVATE HELPER METHODS =====
    /**
     * Executes a query and maps results to GameModel objects.
     */
    private List<GamesPageModel> executeGameQuery(PreparedStatement stmt) throws SQLException {
        List<GamesPageModel> games = new ArrayList<>();
        try (ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                games.add(mapResultSetToGame(rs));
            }
        }
        return games;
    }
    
    /**
     * Maps a ResultSet row to a GameModel object.
     */
    private GamesPageModel mapResultSetToGame(ResultSet rs) throws SQLException {
        GamesPageModel game = new GamesPageModel();
        game.setGameID(rs.getInt("GameID"));
        game.setGameName(rs.getString("GameName"));
        game.setGenre(rs.getString("Genre"));
        game.setDeveloper(rs.getString("Developer"));
        game.setImageUrl(rs.getString("ImageURL"));
        
        // Check for Rating column
        if (columnExists(rs, "Rating")) {
            game.setRating(rs.getFloat("Rating"));
        }
        
        // Check for NumberOfReviews column
        if (columnExists(rs, "NumberOfReviews")) {
            game.setNumberOfReviews(rs.getInt("NumberOfReviews"));
        }
        
        // Optional fields (only mapped if needed)
        if (columnExists(rs, "Description")) {
            game.setDescription(rs.getString("Description"));
        }
        if (columnExists(rs, "ReleasedDate")) {
            game.setReleasedDate(rs.getDate("ReleasedDate").toLocalDate());
        }
        return game;
    }
    
    /**
     * Checks if a column exists in the ResultSet (safe mapping).
     */
    private boolean columnExists(ResultSet rs, String columnName) {
        try {
            rs.findColumn(columnName);
            return true;
        } catch (SQLException e) {
            return false;
        }
    }
}