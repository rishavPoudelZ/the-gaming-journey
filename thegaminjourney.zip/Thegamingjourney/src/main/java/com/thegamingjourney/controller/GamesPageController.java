package com.thegamingjourney.controller;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import com.thegamingjourney.model.GamesPageModel;
import com.thegamingjourney.service.GamesPageService;


@WebServlet("/Games")
public class GamesPageController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private GamesPageService gameService = new GamesPageService();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String genre = request.getParameter("genre");
        String type = request.getParameter("type");

        if (type == null || type.isEmpty()) {
            type = "topRated"; // Default to top-rated
        }

        List<GamesPageModel> games = new ArrayList<>();

        if ("topRated".equals(type)) {
            if (genre == null || genre.isEmpty()) {
                games = gameService.getTopRatedGames(12);
            } else {
                games = gameService.getTopRatedGamesByGenre(genre, 12);
            }
        }

        request.setAttribute("gamesList", games);
        request.setAttribute("genres", gameService.getAllGenres());
        request.setAttribute("currentGenre", genre);
        request.setAttribute("currentType", type);

        request.getRequestDispatcher("/WEB-INF/pages/GamesPage.jsp").forward(request, response);
    }
}